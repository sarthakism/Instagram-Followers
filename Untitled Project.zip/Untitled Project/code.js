//returns owner name at a given rank
//rank(integer) rank of most followed ,used for index
//owner (string)name of the owner of account
function getUserByRank(rank) {
  var ownerList = getColumn("Most Followed Instagram Accounts", "Owner");
  var owner = ownerList[rank - 1];
  return owner;
}


//allows access to the average amount of followers
//average (double) average amount of followers
function getFollowerAverage() {
  var followerList = getColumn("Most Followed Instagram Accounts", "Followers in millions");
  var sum = 0;
  for (var i = 0; i < followerList.length; i++) {
    sum = sum+followerList[i];
  }
  var average = sum / followerList.length;
  return average;
}
